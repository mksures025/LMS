package com.te.golms.exception;

public class EmployeeAttendenceNotUpdatedException extends RuntimeException {
	public EmployeeAttendenceNotUpdatedException(String message) {
		super(message);
	}
}
