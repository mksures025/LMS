package com.te.golms.exception;

public class BatchNotSavedException extends RuntimeException {
	public BatchNotSavedException(String message) {
		super(message);
	}
}
