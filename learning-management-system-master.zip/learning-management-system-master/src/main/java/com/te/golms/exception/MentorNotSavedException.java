package com.te.golms.exception;

public class MentorNotSavedException extends RuntimeException {
	public MentorNotSavedException(String message) {
		super(message);
	}
}
