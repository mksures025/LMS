package com.te.golms.exception;

public class EmployeeRegistrationNotRejected extends RuntimeException {
	public EmployeeRegistrationNotRejected(String message) {
		super(message);
	}
}
