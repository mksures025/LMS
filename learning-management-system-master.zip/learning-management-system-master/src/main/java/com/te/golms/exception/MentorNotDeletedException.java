package com.te.golms.exception;

public class MentorNotDeletedException extends RuntimeException {
	public MentorNotDeletedException(String message) {
		super(message);
	}
}
