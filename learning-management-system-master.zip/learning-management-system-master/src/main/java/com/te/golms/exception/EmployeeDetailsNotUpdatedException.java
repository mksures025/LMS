package com.te.golms.exception;

public class EmployeeDetailsNotUpdatedException extends RuntimeException {
	public EmployeeDetailsNotUpdatedException(String message) {
		super(message);
	}
}
