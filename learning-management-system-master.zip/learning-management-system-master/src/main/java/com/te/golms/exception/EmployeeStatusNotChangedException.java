package com.te.golms.exception;

public class EmployeeStatusNotChangedException extends RuntimeException {
	public EmployeeStatusNotChangedException(String message) {
		super(message);
	}
}
