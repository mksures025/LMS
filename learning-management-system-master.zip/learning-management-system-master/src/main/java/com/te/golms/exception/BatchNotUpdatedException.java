package com.te.golms.exception;

public class BatchNotUpdatedException extends RuntimeException {
	public BatchNotUpdatedException(String message) {
		super(message);
	}
}
