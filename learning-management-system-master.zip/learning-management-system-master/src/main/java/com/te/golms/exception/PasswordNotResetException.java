package com.te.golms.exception;

public class PasswordNotResetException extends RuntimeException {
	public PasswordNotResetException(String message) {
		super(message);
	}
}
