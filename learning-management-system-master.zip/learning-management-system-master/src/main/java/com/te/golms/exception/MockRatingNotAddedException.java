package com.te.golms.exception;

public class MockRatingNotAddedException extends RuntimeException {
	public MockRatingNotAddedException(String message) {
		super(message);
	}
}
