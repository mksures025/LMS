package com.te.golms.exception;

public class BatchNotDeletedException extends RuntimeException {
	public BatchNotDeletedException(String message) {
		super(message);
	}
}
