package com.te.golms.exception;

public class EmployeeNotAddedToBatchException extends RuntimeException {
	public EmployeeNotAddedToBatchException(String message) {
		super(message);
	}
}
