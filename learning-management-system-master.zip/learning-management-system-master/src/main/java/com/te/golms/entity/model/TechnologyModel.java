package com.te.golms.entity.model;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TechnologyModel {
	private String technologyName;
}
