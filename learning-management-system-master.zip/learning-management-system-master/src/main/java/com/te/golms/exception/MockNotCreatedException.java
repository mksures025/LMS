package com.te.golms.exception;

public class MockNotCreatedException extends RuntimeException {
	public MockNotCreatedException(String message) {
		super(message);
	}
}
