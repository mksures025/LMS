package com.te.golms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GolmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
